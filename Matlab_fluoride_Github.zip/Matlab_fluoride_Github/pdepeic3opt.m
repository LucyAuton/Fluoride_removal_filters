function u0 = pdepeic3opt(x,c2i)
    %Code written by M. Martínez I. Àvila and A. Valverde
    %Function to construct the ICs (Equation 20f) in correct format for
    %MATLAB function pdepe, to be used in the optimisation.
    %For details on u0, search matlab pdepe
    u0 = [0;c2i;0;0;0]; 
end