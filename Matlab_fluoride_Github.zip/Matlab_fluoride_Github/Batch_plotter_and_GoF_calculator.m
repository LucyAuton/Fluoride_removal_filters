function [sse_iso_MRC,Rsquared_iso_MRC, sse_kin_MRC,Rsquared_kin_MRC,sse_iso_TMRC,Rsquared_iso_TMRC,sse_kin_TMRC,...
Rsquared_kin_TMRC, cFi_MRC, cOHi, cFe_MRC, cFi_TMRC, cFe_TMRC, K2, KT] = Batch_plotter_and_GoF_calculator(x)
    
    %Code written by L. C. Auton, based on codes by M. Martínez I. Àvila and A. Valverde

    % Call function to genreate solutions and the goodness of fit parameters 
    [ ce_model_MRC, qe_model_MRC, ce_model_TMRC,  qe_model_TMRC, ...
    MRC_iso_data, TMRC_iso_data,  cs_kin, ts_kin, cs_kin_data, ts_kin_data, ...
    sse_iso_MRC, sse_iso_TMRC, Rsquared_MRC, Rsquared_TMRC,  val_kins_SSE, ...
    R_2_kins, cFis, cOHi, cFe_MRC, cFe_TMRC, K2, KT] = FitParam(x); 

    cFi_MRC = cFis(1);
    cFi_TMRC = cFis(2);
    
    % Goodness of fit parameters 
    % MRC 
    Rsquared_iso_MRC = Rsquared_MRC;
    sse_kin_MRC = val_kins_SSE(1);
    Rsquared_kin_MRC = R_2_kins(1);
    % TMRC 
    Rsquared_iso_TMRC = Rsquared_TMRC;
    sse_kin_TMRC =val_kins_SSE(2);
    Rsquared_kin_TMRC =  R_2_kins(2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Plots and export pdfs of figures 4 and 6. 

    %Define colours and font size
    nl=10;
    nc = 100;
    cmap = parula(nc);
    cmap2 = fliplr(parula(nc));
    
    
    figure(1);
    subplot(121)
    hold on
    %Set up for main 
    h_main = gca;
    set(h_main,'FontSize',nl,'FontName','Times New Roman','LineWidth',1)
    
    %Set up for inset (postitoning and font size)
    h_inset = axes('Position',[0.272 0.25 0.18 0.3]); 
    %         % first number increasing it moves it to the right 
    %         % second increasing it moves it up 
    %         % third number controls insert width 
    %         % fourth controls insert height
    set(h_inset,'FontSize',nl-2,'FontName','Times New Roman','LineWidth',1)
    
    %Plot main figure
    axes(h_main)
    hold on
    scatter(MRC_iso_data(1,:),MRC_iso_data(2,:),'marker','o', 'MarkerEdgeColor', cmap2(round(nc/10),:),'LineWidth', 1);
    plot(ce_model_MRC,qe_model_MRC,'Color',[.5 .5 0],'LineWidth', 1.5);
    
    % Main axis labels
    axes(h_main)
    title('Pure MRC isotherm','FontSize',nl,'FontName','Times New Roman','LineWidth',1)
    box on
    xlabel('$c_\mathrm{F}^\mathrm{e}\ $(mol$/$l) ','interpreter','latex')
    ylabel('$q^\mathrm{e}\ $(mol$/$g)','interpreter','latex')
    set(h_main,'xscale','lin')
    set(h_main,'yscale','lin')
    
    axes(h_inset)
    hold all; hold on
    loglog(ce_model_MRC(2:end),qe_model_MRC(2:end),'Color',[.5 .5 0],'LineWidth', 1.5);
    scatter(MRC_iso_data(1,:),MRC_iso_data(2,:),'marker','o', 'MarkerEdgeColor',cmap2(round(nc/10),:),'LineWidth', 1);
    
    %Inset axis labels
    axes(h_inset)
    box on
    set(h_inset,'xscale','log')
    set(h_inset,'yscale','log')
    set(gca,'XTick',[1e-5  1e-3  1e-1])
    set(gca,'YTick',[1e-5  1e-4  1e-3])
    ylim([1e-5 1e-3])
    xlim([1e-5 1e-1])
    set(gca, 'XMinorTick','off')
    set(gca, 'YMinorTick','off')
    
    subplot(122)
    hold all
    h_main = gca;
    set(h_main,'FontSize',nl,'FontName','Times New Roman','LineWidth',1)
    h_inset = axes('Position',[0.71 0.48 0.18 0.35]); 
    % first number increasing it moves it to the right 
    % second increasing it moves it up 
    % third number controls insert width 
    % fourth controls insert height
    set(h_inset,'FontSize',nl-2,'FontName','Times New Roman','LineWidth',1)
    
    %Plot main figure
    axes(h_main)
    hold on
    plot(ts_kin{1},cs_kin{1},'Color',cmap(1,:),'LineWidth', 1.5);
    hold on 
    scatter(ts_kin_data{1},cs_kin_data{1},'marker','square', 'MarkerEdgeColor',cmap(round((nc+20)/2),:),'LineWidth', 1);
    title('Pure MRC kinetics','FontSize',nl,'FontName','Times New Roman','LineWidth',1)
    
    %Plot inset figure
    axes(h_inset)
    hold on;
    scatter(ts_kin_data{1},cs_kin_data{1},'marker','square', 'MarkerEdgeColor',cmap(round((nc+20)/2),:),'LineWidth', 1);
    loglog(ts_kin{1},cs_kin{1},'Color',cmap(1,:),'LineWidth', 1.5);
    
    % Main axis labels
    axes(h_main)
    box on
    set(gca,'FontSize',nl,'FontName','Times New Roman','LineWidth', 1)
    xlabel('$t\ $(mins) ','interpreter','latex')
    ylabel('$c_\mathrm{F}\ $(mol/l) ','interpreter','latex')
    set(h_main,'xscale','lin')
    set(h_main,'yscale','lin')
    
    %Inset axis labels
    axes(h_inset)
    box on
    set(h_inset,'xscale','log')
    set(h_inset,'yscale','lin')
    xlim([2 5000])
    set(gca,'XTick',[1e-1  1e1  1e3])
    set(gca, 'XMinorTick','off')
    set(gca, 'YMinorTick','off')
    
    %Prettify and print  figure
    figw = 17.2;
    figh = figw/(2.7);
    set(gcf,'PaperUnits','centimeters')
    set(gcf,'PaperSize',[figw figh])
    set(gcf,'PaperPosition',[-1.8 0.5 figw+3.39 .9*figh])
    % first number controls left shift (smaller --> left )
    % second number controls up/down postion (bigger --> up)
    % third number controls width in relation to paper size 
    print(gcf,'-dpdf','./Figures/MRC_iso_plus_kinetics.pdf'); %,'./Figures/MRC_iso_plus_kinetics.pdf')
    
    figure(2);
    subplot(121)
    hold all
    %Set up for main 
    h_main = gca;
    set(h_main,'FontSize',nl,'FontName','Times New Roman','LineWidth',1)
    
    %Set up for inset (postitoning and font size)
    h_inset = axes('Position',[0.272 0.25 0.18 0.3]); 
    %         % first number increasing it moves it to the right 
    %         % second increasing it moves it up 
    %         % third number controls insert width 
    %         % fourth controls insert height
    set(h_inset,'FontSize',nl-2,'FontName','Times New Roman','LineWidth',1)
    
    %Plot main figure
    axes(h_main)
    hold on
    scatter(TMRC_iso_data(1,:),TMRC_iso_data(2,:),'marker','o', 'MarkerEdgeColor',cmap2(round(nc/10),:),'LineWidth', 1);
    plot(ce_model_TMRC,qe_model_TMRC,'Color',[.5 .5 0],'LineWidth', 1.5);
  
    % Main axis labels
    axes(h_main)
    title('Pure TMRC isotherm','FontSize',nl,'FontName','Times New Roman','LineWidth',1)
    box on
    xlabel('$c_\mathrm{F}^\mathrm{e}\ $(mol$/$l) ','interpreter','latex')
    ylabel('$q^\mathrm{e}\ $(mol$/$g)','interpreter','latex')
    set(h_main,'xscale','lin')
    set(h_main,'yscale','lin')
    
    axes(h_inset)
    hold all; hold on;
    loglog(ce_model_TMRC(2:end),qe_model_TMRC(2:end),'Color',[.5 .5 0],'LineWidth', 1.5);
    scatter(TMRC_iso_data(1,:),TMRC_iso_data(2,:),'marker','o', 'MarkerEdgeColor',cmap2(round(nc/10),:),'LineWidth', 1);    
    
    %Inset axis labels
    axes(h_inset)
    box on
    set(h_inset,'xscale','log')
    set(h_inset,'yscale','log')
    
    
    subplot(122)
    hold all
    h_main = gca;
    set(h_main,'FontSize',nl,'FontName','Times New Roman','LineWidth',1)
    h_inset = axes('Position',[0.68 0.45 0.2 0.37]); 
    % first number increasing it moves it to the right 
    % second increasing it moves it up 
    % third number controls insert width 
    % fourth controls insert height
    set(h_inset,'FontSize',nl-2,'FontName','Times New Roman','LineWidth',1)
    
    %Plot main figure
    axes(h_main)
    hold on
    plot(ts_kin{2},cs_kin{2},'Color',cmap(1,:),'LineWidth', 1.5);
    hold on 
    scatter(ts_kin_data{2},cs_kin_data{2},'marker','square', 'MarkerEdgeColor',cmap(round((nc+20)/2),:),'LineWidth', 1);
    title('Pure TMRC kinetics','FontSize',nl,'FontName','Times New Roman','LineWidth',1)
    
    %Plot inset figure
    axes(h_inset)
    hold on;
    scatter(ts_kin_data{2},cs_kin_data{2},'marker','square', 'MarkerEdgeColor',cmap(round((nc+20)/2),:),'LineWidth', 1);
    plot(ts_kin{2},cs_kin{2},'Color',cmap(1,:),'LineWidth', 1.5);
    
    % Main axis labels
    axes(h_main)
    box on
    set(gca,'FontSize',nl,'FontName','Times New Roman','LineWidth', 1)
    xlabel('$t\ $(mins) ','interpreter','latex')
    ylabel('$c_\mathrm{F}\ $(mol/l) ','interpreter','latex')
    set(h_main,'xscale','lin')
    set(h_main,'yscale','lin')
    
    %Inset axis labels
    axes(h_inset)
    box on
    set(h_inset,'xscale','lin')
    set(h_inset,'yscale','lin')
    ylim([0 5e-4])
    xlim([0 500])
    set(gca, 'XMinorTick','off')
    set(gca, 'YMinorTick','off')
    
    %Prettify and print  figure
    figw = 17.2;
    figh = figw/(2.7);
    set(gcf,'PaperUnits','centimeters')
    set(gcf,'PaperSize',[figw figh])
    set(gcf,'PaperPosition',[-1.8 0.5 figw+3.39 .9*figh])
    % first number controls left shift (smaller --> left )
    % second number controls up/down postion (bigger --> up)
    % third number controls width in relation to paper size
    print(gcf,'-dpdf','./Figures/TMRC_iso_plus_kinetics.pdf')
   

    function [ce_model_MRC, qe_model_MRC, ce_model_TMRC,  qe_model_TMRC, ...
            MRC_iso_data, TMRC_iso_data,  cs_kin, ts_kin, cs_kin_data, ts_kin_data, sse_iso_MRC, ...
            sse_iso_TMRC, Rsquared_MRC, Rsquared_TMRC,  val_kins_SSE, R_2_kins, CF0s, ...
            cOH0, cFe, c_TMRC_e, K2, KT] = FitParam(x)
    

        %Unpack the 7 batch fitting parameters 
        K1 = x(1);
        chi = x(2);
        qm_MRC = x(3);
        qmT = x(4);
        ka1 = x(5); 
        ka2 = x(6); 
        kaT = x(7);
        
        %Construct qm1 and qm2 from chi and qm_MRC
        qm1 = qm_MRC*(1-chi);
        qm2 = qm_MRC*chi;
        
        % -----------------------------------
        %To convert concentrations between mg/l and mol/l
        F_fac = 1/19000;
        OH_fac = 1/17000;
        
        %Experimental data
        t_MRC  = [0 5 10 20 40 60 120 180 240 360 480 720 1080 1440 2880]; 
        t_TMRC = [0 5 10 20 40 60 120 180 240 360 480 1080 1440 2880]; 
        c_MRC = F_fac*[10 10 10 9.6 9.2 9 8.4 8.1 8 7.4 6.6 5.4 4.2 3.9 3.5];
        c_TMRC = F_fac*[50 6.9 5.8 4.9 3.6 2 0.5 0.45 0.4 0.4 0.3 0.08 0.08 0.08];
        c_TMRC_e = c_TMRC(end);
        
        %-----------------------------------------------------
        cOH0 = 1.7000e-3*OH_fac;    % Inital concentration of OH mol/l from pH=7.
        fs = [0, 1]; %f is the fraction of TMRC so that: f = 0 is MRC, f=1 is TMRC 
        %-----------------------------------------------------
        
        CF0s = [c_MRC(1)  c_TMRC(1)];
        gamma_kin = 1; 
        gamma_iso = 7; 
        tss = [0, logspace(-2,log10(3000),999)]; 
        
        % Initialise vectors (preallocate size for speed)
        cs_kin{1} = zeros(length(tss), 1);
        cs_kin{2} = cs_kin{1};
        ts_kin{1} = cs_kin{1};
        ts_kin{2} = cs_kin{1};
        cs_kin_data{1} = zeros(size(c_MRC));
        cs_kin_data{2} = zeros(size(c_TMRC));
        ts_kin_data{1} = cs_kin_data{1};
        ts_kin_data{2} = cs_kin_data{2};
        val_kins_SSE = zeros(2,1);
        val_kins_SST = zeros(2,1);
        R_2_kins = zeros(2,1);

        %Calculate KT and K2 according to equations (19) and (10), respectively
        KT = (c_TMRC(1)-c_TMRC(end))*(c_TMRC(1)-c_TMRC(end)+cOH0)/c_TMRC(end)...
        /(gamma_kin*qmT-c_TMRC(1)+c_TMRC(end));
        
        cFe = c_MRC(end); 
        q1e_MRC = (-(cOH0+K1*cFe)+sqrt((cOH0+K1*cFe)^2+...
        4*gamma_kin*K1*cFe*qm1))/2/gamma_kin;
        
        K2 = (CF0s(1)-cFe-gamma_kin*q1e_MRC)/cFe/...
        (gamma_kin*(qm2+q1e_MRC)+cFe-CF0s(1));


        %Kinetic curves 
        for imix = 1:length(fs)
            f = fs(imix);
            cF0 = CF0s(imix);
      
            if imix == 1   
                ts_concat = t_MRC;
                cs_data = c_MRC;
                
                %Define paramters to import into the function
                %MRC_kin_helper, which is use to solve the MRC kinetics
                params = [ka1 K1  ka2 K2 chi qm_MRC f cF0 gamma_kin];
                
                % Solve for the kinetic curves
                options = odeset('RelTol',1e-10,'AbsTol',1e-12);
                InitialCond = [0 0]; 
                [T, Y] = ode15s(@(t,x)MRC_kin_helper(t,x,params),tss,InitialCond,options);
                q1(:,1) = Y(:,1);
                q2(:,1) = Y(:,2);
             
                gammaBM = (1-f)*gamma_kin; 
                
                cs_kin{imix} = cF0-(gammaBM*(q1(:,imix)+q2(:,imix)));
            else
                ts_concat = t_TMRC;
                cs_data= c_TMRC;
                
                kdT=kaT/KT;
                A = gamma_kin*(kaT-kdT);
                B = kaT*(gamma_kin*qmT+CF0s(2))+kdT*cOH0;
                D = kaT*cF0*qmT;
                
                Rminus = (B-sqrt(B^2-4*A*D))/2/A;
                Rplus = (B+sqrt(B^2-4*A*D))/2/A;
                
                ts_TMRC_ana = tss;
                qT_ana = Rplus*(exp(-A*(Rplus-Rminus)*ts_TMRC_ana)-1)./...
                (exp(-A*(Rplus-Rminus)*ts_TMRC_ana)-Rplus/Rminus);
                
                cs_kin{imix} = cF0-gamma_kin*qT_ana;
            end 
        
            cMatch = interp1(T,cs_kin{imix},ts_concat); 
            ts_kin{imix} = T;
            ts_kin_data{imix} = ts_concat; 
            cs_kin_data{imix} = cs_data; 
            
            % Calculate the dimensionless SSE and R^2. 
            val_kins_SSE(imix) = sum( (cs_data-cMatch).^2 )/(CF0s(imix)^2);
            val_kins_SST(imix) = sum( (cs_data-mean(cs_data)).^2)/(CF0s(imix)^2);
            R_2_kins(imix) = 1-val_kins_SSE(imix)./val_kins_SST(imix);
        end 
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Isotherm
        %----------------------------------------------------
        %Data
        Bce_TMRC = F_fac*[0 0 0 0.053763440860215055 0.6989247311827957 2.2580645161290325 ...
                   4.89247311827957 25.053763440860216];
        Bqe_TMRC = F_fac*[0 3.1400966183574877 7.971014492753623 15.700483091787438 ...
                   31.884057971014492 62.56038647342995 92.27053140096618 120.53140096618357];
        
        Bce_MRC = F_fac*[0 0 1.0905125408942202 2.1810250817884405 23.991275899672846 64.34023991275899...
                  170.52631578947367 382.10526315789474 540 730.6434023991276];
        Bqe_MRC = F_fac*[0 0.684931506849315 1.5981735159817352 2.557077625570776 4.4520547945205475...
                  6.415525114155251  9.132352941176471 11.316176470588236 12.75 13.378995433789953];
        
        MRC_iso_data = [Bce_MRC; Bqe_MRC];
        TMRC_iso_data = [Bce_TMRC; Bqe_TMRC ];
        
        % -----------------------------
        %Calculate MRC isotherm 
        a = cOH0/gamma_iso;
        b = K1/gamma_iso;
        d = K1*qm1/gamma_iso; %K1 K2 qm chi 
        qMatch_MRC = 1/2.*( -(a+b.*Bce_MRC) + ((a+b.*Bce_MRC).^2+4.*d.*Bce_MRC).^(1/2))+(qm2.*K2.*Bce_MRC)./(1+K2.*Bce_MRC);
        
        ce_model_MRC = linspace(Bce_MRC(1), Bce_MRC(end), 1000); 
        qe_model_MRC = 1/2.*( -(a+b.*ce_model_MRC) + ((a+b.*ce_model_MRC).^2+4.*d.*ce_model_MRC).^(1/2))+(qm2.*K2.*ce_model_MRC)./(1+K2.*ce_model_MRC);
        
        
        %Calculate TMRC isotherm
        bT = KT/gamma_iso; dT = KT*qmT/gamma_iso;
        qMatch_TMRC = 1/2.*(-(a+bT.*Bce_TMRC) + ((a+bT.*Bce_TMRC).^2+4.*dT.*Bce_TMRC).^(1/2));
        
        ce_model_TMRC = linspace(Bce_TMRC(1), Bce_TMRC(end), 1000); 
        qe_model_TMRC =1/2.*(-(a+bT.*ce_model_TMRC) + ((a+bT.*ce_model_TMRC).^2+4.*dT.*ce_model_TMRC).^(1/2));
        
        %------------------------------------------------------------
        
        %Calculate the goodness of fit parameters form the MRC isotherm
        sse_iso_MRC = sum( (Bqe_MRC-qMatch_MRC).^2)/Bqe_MRC(end)^2;
        sst_iso_MRC = sum((Bqe_MRC-mean(Bqe_MRC)).^2)/Bqe_MRC(end)^2;
        Rsquared_MRC = 1-sse_iso_MRC/sst_iso_MRC;
        
        %Calculate the goodness of fit parameters form the TMRC isotherm
        sse_iso_TMRC = sum( (Bqe_TMRC-qMatch_TMRC).^2)/Bqe_TMRC(end)^2;
        sst_iso_TMRC = sum((Bqe_TMRC-mean(Bqe_TMRC)).^2)/Bqe_TMRC(end)^2;
        Rsquared_TMRC = 1-sse_iso_TMRC/sst_iso_TMRC;
        
    end
    
    
    function [dQidt] = MRC_kin_helper(t,x,params)
        
        % VARIABLES
        q1 = x(1); 
        q2 = x(2); 
       
        %Unpack paramters 
        ka1 = params(1);
        K1 = params(2);
        ka2 = params(3);
        K2 = params(4);   
        chi = params(5);
        qm_MRC = params(6);
        f = params(7);
        cF0 = params(8);  
        gamma_kin= params(9);
        
        % To convert units between mg/l and mol/l for OH
        OH_fac = 1/17000;
        
        %Initial condition for OH, based on pH 7. 
        cOH0 = 1.7000e-3*OH_fac; 
        
        % Construct backward reaction rates and qm1 and qm2
        kd1 = ka1/K1;
        kd2 = ka2/K2;
        
        qm1 = qm_MRC*(1-chi);
        qm2 = qm_MRC*chi;
        
        %Present problem
        gammaBM = (1-f)*gamma_kin; 
        
        cF = cF0-(gammaBM*(q1+q2));
        cOH = cOH0+(gammaBM*(q1));
        
        %Kinetic equations
        dq1dt = ka1*cF.*(qm1-q1)-kd1*cOH.*q1;
        dq2dt = ka2*cF.*(qm2-q2)-kd2*q2;
        
        %Vector of equations to solve
        dQidt = [dq1dt; dq2dt]; 
    end 
end 