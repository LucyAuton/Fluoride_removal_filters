function c1calc = Varying_flow_rate_opt_helper(paropt,texp,D1,D2,vs,qm1,qmT,qm2,c2i,K1,KT,K2,tmesh,Nbi)
    %Code written by L. C. Auton, based on codes by M. Martínez I. Àvila and A. Valverde

    %Unpack parameters to optimise  
    cf = paropt(1);
    f = paropt(2);
    Lb = paropt(3);
    ka1=paropt(4);
    kaT=paropt(5);
    ka2=paropt(6);
    
    kd1=ka1/K1;
    kdT=kaT/KT;
    kd2=ka2/K2;
    
    %Construct physcial parameters
    rhob1=(1-f)*900;               
    rhob2=f*980;
    phi=(1-f)*0.5+f*0.6;
    v=vs/phi;  %Interstitial velocity [dm/s]
    
    %Construct spatial mesh 
    xmesh = linspace(0,Lb,Nbi);
    
    %Solve PDE
    mpdepe = 0;
    sol = pdepe(mpdepe,@(x,t,u,dudx) ....
        pdepefun3opt(x,t,u,dudx,v,D1,D2,rhob1,rhob2,phi,ka1,kaT,ka2,kd1,kdT,kd2,qm1,qmT,qm2),...
        @(x) pdepeic3opt(x,c2i),@(xl,ul,xr,ur,t) pdepebc3opt(xl,ul,xr,ur,t,v,cf,c2i),xmesh,tmesh);
    
    %Extract cF and calculate cF at outlet 
    c1=sol(:,:,1);
    c1ciout=c1(:,Nbi)/cf;
    
    %Interpolate solution at outlet in time 
    c1calc=interp1(tmesh,c1ciout',texp*3600);
end

