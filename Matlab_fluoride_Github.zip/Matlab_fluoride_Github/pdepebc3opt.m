function [pl,ql,pr,qr] = pdepebc3opt(xl,ul,xr,ur,t,v,c1i,c2i)
    %Code written by M. Martínez I. Àvila and A. Valverde
    %Function to construct the BCs (Equation 20g) in correct format for
    %MATLAB function pdepe, to be used in the optimisation.
    %For details on pl ql pr qr, search matlab pdepe
    pl = [v*c1i;v*c2i;0;0;0];
    ql = [1;1;1;1;1];
    pr = [v*ur(1);v*ur(2);0;0;0];
    qr = [1;1;1;1;1];
end